// NAMA       : Muhammad Hasan
// NIM        : 13518012
// Tanggal    : 17/10/2019
// Deskripsi  : Mengimplementasikan ekspresi.c
#include <stdio.h>
#include "mesintoken.h"
#include "stackt.h"

int fast(int x, int y) {
	int ret = 1;
	while (y > 0) {
		if (y & 1) ret *= x;
		y >>= 1;
		x = (x * x);
	}
	return ret;
}
 
int main() {
	
	int s[100000];
	int len = 0;
	STARTTOKEN();
	while (!EndToken) {
		if (CToken.tkn == 'b') {
			printf("%d\n", CToken.val);
			s[++len] = CToken.val;
		} else {
			int x = s[len--];
			int y = s[len];
			char z = CToken.tkn;
			printf("%d %c %d\n", y, CToken.tkn, x);
			if (z == '+') {
				y += x;
			} else if (z == '-') {
				y -= x;
			} else if (z == '/') {
				y /= x;
			} else if (z == '*') {
				y *= x;
			} else if (z == '^') {
				y = fast(y, x);
			}
			printf("%d\n", y);
			s[len] = y;
		}
		ADVTOKEN();
	}
	if (len == 0) {
		printf("Ekspresi kosong\n");
	} else {
		printf("Hasil=%d\n", s[1]);
	}
	
	return 0;
}