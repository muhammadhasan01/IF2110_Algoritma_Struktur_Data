// Muhammad Hasan - 13518012
// Tanggal : 28/08/2019
// Deskripsi : Driver untuk point.c

#include <stdio.h>
#include "point.c"

int main() {

    POINT point, point2;
    BacaPOINT(&point);
    TulisPOINT(point);
    point2 = point;
    if (EQ(point, point2)) {
        printf("SAMA\n");
    }
    point2 = NextX(point2);
    if (NEQ(point, point2)) {
        printf("BEDA\n");
    }
    if (IsOrigin(point)) {
        printf("Point ada pada origin\n");
    } else {
        printf("Point tidak ada di origin\n");
    }
    if (IsOnSbX(point)) {
        printf("Point berada pada sumbu-X\n");
    } else {
        printf("Point tidak berada pada sumbu-x\n");
    }
    if (IsOnSbY(point)) {
        printf("Point berada pada sumbu-Y\n");
    } else {
        printf("Point tidak berada pada sumbu-Y\n");
    }
    printf("Point berada pada kuadran %d\n", Kuadran(point));
    Geser(&point, 3, 2);
    TulisPOINT(point);
    GeserKeSbX(&point);
    TulisPOINT(point);
    GeserKeSbY(&point);
    TulisPOINT(point);
    Geser(&point, 9, 9);
    Mirror(&point, true);
    TulisPOINT(point);
    Mirror(&point, false);
    TulisPOINT(point);
    Putar(&point, 180);
    TulisPOINT(point);

    return 0;
}
