// Muhammad Hasan - 13518012
// Tanggal : 28/08/2019
// Deskripsi : Driver untuk jam.c
#include <stdio.h>
#include "jam.c"

int main() {

    JAM jam;
    BacaJAM(&jam);
    TulisJAM(jam);
    long hasilDetik = JAMToDetik(jam);
    printf("Jam dalam detik adalah %ld\n", hasilDetik);
    printf("Tadi jamnya adalah : ");
    TulisJAM(DetikToJAM(hasilDetik));
    JAM jam2;
    BacaJAM(&jam2);
    printf("Durasi jam pertama ama kedua adalah %ld\n", Durasi(jam, jam2));
    if (JEQ(jam, jam2)) {
        printf("SAMA\n");
    }
    if (JNEQ(jam, jam2)) {
        printf("BEDA\n");
    }



    return 0;
}
