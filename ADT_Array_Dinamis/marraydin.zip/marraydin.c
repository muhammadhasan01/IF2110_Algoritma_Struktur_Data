// NAMA/NIM		: Muhammad Hasan/13518012
// Tanggal 		: 12 September 2019
// Deskripsi	: Menggunakan ADT Array Dinamis

#include <stdio.h>
#include "arraydin.h"

TabInt T;
int maksElement, q, op, num;


int main() {
	
	scanf("%d", &maksElement);
	MakeEmpty(&T, maksElement);
	BacaIsi(&T);
	scanf("%d", &q);
	while (q--) {
		scanf("%d", &op);
		if (op == 1) {
			scanf("%d", &num);
			if (IsFull(T)) {
				printf("array sudah penuh\n");
			} else {
				AddAsLastEl(&T, num);
				printf("%d ", MaxEl(T));
				TulisIsiTab(T);
				printf("\n");
			}
		} else if (op == 2) {
			scanf("%d", &num);
			GrowTab(&T, num);
			printf("%d ", MaxEl(T));
			TulisIsiTab(T);
			printf("\n");
		} else if (op == 3) {
			scanf("%d", &num);
			if (MaxEl(T) < num) {
				printf("array terlalu kecil\n");
			} else {
				ShrinkTab(&T, num);
				printf("%d ", MaxEl(T));
				TulisIsiTab(T);
				printf("\n");
			}
		} else if (op == 4) {
			CompactTab(&T);
			printf("%d ", MaxEl(T));
			TulisIsiTab(T);
			printf("\n");
		}

	}

	return 0;
}